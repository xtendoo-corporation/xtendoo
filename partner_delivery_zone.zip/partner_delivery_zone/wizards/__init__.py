# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import partner_delivery_zone_wizard
from . import wizard_report_sale_delivery_zone
