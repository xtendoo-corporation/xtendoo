This module allows to set delivery zones on partner. This information is
written in sale orders and stock pickings.
It also adds searches and groups in partners, sales orders and stock pickings
views.
