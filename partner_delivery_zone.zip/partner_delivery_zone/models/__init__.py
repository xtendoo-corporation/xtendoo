# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import partner_delivery_zone
from . import partner_delivery_zone_line
from . import partner_delivery_zone_visit
from . import res_partner
from . import sale_order
from . import stock_move
from . import stock_picking
from . import account_payment
from . import account_invoice
